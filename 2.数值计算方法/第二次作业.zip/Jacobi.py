# -*- coding:utf-8 -*-
'''
@File    :   Jacobi.py
@Time    :   2022/04/01 09:35:58
@Author  :   hyh
@Version :   1.0
@Contact :   1360895771@qq.com
@Desc    :   雅可比迭代法
'''
# here put the import lib
from re import L
import numpy as np
def jacobi(a,b,x0,eps):
    D = np.diag(np.diag(a))
    L = -np.tril(a,-1)
    U = -np.triu(a,1)
    B=D/(L+U)
    f = D/b
    y = B*x0+f
    n = 1
    while np.linalg.norm(y-x0)>=eps:
        x0=y
        y=B*x0+f
        n=n+1

a = np.array ([[14,2,1,5],
              [8,17,2,10],
              [4,18,3,6],
              [12,26,11,20]])
b = np.array([1,2,3,4])
x0 = np.array([0,0,0,0])
jacobi(a,b,x0,0.0001)


